# Sign language > 2024-12-16 1:58pm
https://universe.roboflow.com/rajalaxmi-kr/sign-language-lyvxr

Provided by a Roboflow user
License: CC BY 4.0

